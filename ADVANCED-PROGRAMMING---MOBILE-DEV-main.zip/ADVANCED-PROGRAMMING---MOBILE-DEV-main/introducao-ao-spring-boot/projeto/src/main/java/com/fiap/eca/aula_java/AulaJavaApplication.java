package com.fiap.eca.aula_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulaJavaApplication.class, args);
	}

}
