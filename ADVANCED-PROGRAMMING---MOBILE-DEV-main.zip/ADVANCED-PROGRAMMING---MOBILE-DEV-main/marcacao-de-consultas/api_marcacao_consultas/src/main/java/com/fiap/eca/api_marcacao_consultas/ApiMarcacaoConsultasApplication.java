package com.fiap.eca.api_marcacao_consultas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication


public class ApiMarcacaoConsultasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMarcacaoConsultasApplication.class, args);
	}

}
