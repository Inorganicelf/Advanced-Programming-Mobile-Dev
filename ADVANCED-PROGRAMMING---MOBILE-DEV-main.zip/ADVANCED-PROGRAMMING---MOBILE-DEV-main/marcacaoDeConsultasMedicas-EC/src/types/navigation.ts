export type RootStackParamList = {
    Home: undefined;
    CreateAppointment: undefined;
    Profile: undefined;
  };